using System.Collections.Generic;
using shopapp.entity;

namespace shopapp.webui.Models
{
    public class CategoryListViewModel
    {
        public List<Category> Categories { get; set; }
    }
}