﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SQLite;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using System.Security.AccessControl;
using System.Security.Principal;


namespace TelefonRehberi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();



        }
        SQLiteConnection baglanti = new SQLiteConnection("Data Source = Personel.db; Version = 3;");
     
        SQLiteCommand komut;
        SQLiteDataAdapter da;

        
        public void PersonelGetir()
        {  //İşlemler yapıldıktan sonra güncel tabloyu getirir ve bazı fonksiyolarda bağlantı işlemini yapar.
            //Yeniden Class ve using kullanılarak tasarlanabilir.
            //baglanti = new SQLiteConnection("Data Source = Personel.db");
            baglanti.Open();
            da = new SQLiteDataAdapter("SELECT *FROM Personel", baglanti);
            DataTable tablo = new DataTable();
            da.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();

        }
      

        public void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }

      

        public void Form1_Load(object sender, EventArgs e)
        {

            PersonelGetir();
            GC.Collect();
            


            string[] KatSecenekeleri = new string[] { "0-Zemin kat", "1.kat", "2.kat", "3.kat", "4.kat" };
            combobox_1.DataSource = KatSecenekeleri;
            combobox_1.SelectedIndex = 2;
            ClearTextBoxes();



        }
        


        public void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            textid.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textAd.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textSoyad.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            combobox_1.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textTelefon.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();


        }

       

        public void button_Kaydet_Click(object sender, EventArgs e)
        {
            try
            {
                if (textAd.Text == String.Empty || textSoyad.Text == String.Empty || combobox_1.Text == String.Empty || textTelefon.Text == String.Empty)
                {
                    MessageBox.Show("Boş alan bırakılamaz !", "UYARI", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else if (karsilastir(textTelefon.Text))
                {

                    string sorgu = "INSERT INTO Personel(Ad,Soyad,Katı,TelefonNumarası) VALUES(@Ad,@Soyad,@Katı,@TelefonNumarası)";
                    komut = new SQLiteCommand(sorgu, baglanti);
                    komut.Parameters.AddWithValue("@Ad", textAd.Text);
                    komut.Parameters.AddWithValue("@Soyad", textSoyad.Text);
                    komut.Parameters.AddWithValue("@Katı", combobox_1.Text);
                    komut.Parameters.AddWithValue("@TelefonNumarası", textTelefon.Text);
                    baglanti.Open();
                    komut.ExecuteNonQueryAsync();
                    baglanti.Close();
                    PersonelGetir();
                    MessageBox.Show("Başarılı bir biçimde kayıt oldunuz", "BAŞARILI", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearTextBoxes();


                }

                else
                {
                    MessageBox.Show("Bu telefon numarasına ait kayıt bulunmaktadır.Yeni bir kayıt oluşturunuz.", "UYARI", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            }

        public bool karsilastir(string data)
        {   //Karşılaştırma fonksiyonu
          
            baglanti.Open();
            string sorgu = "SELECT TelefonNumarası FROM Personel WHERE TelefonNumarası=@Ad";
            komut = new SQLiteCommand(sorgu, baglanti);
            komut.Parameters.AddWithValue("@Ad", data);

            SQLiteDataReader varmi = komut.ExecuteReader();

            if (varmi.Read())
            {
                baglanti.Close();
                return false; // veri tabanında var
            }
            else
            {
                baglanti.Close();
                return true; //veri tabanında yok
            }


        }

        public void button_Sil_Click(object sender, EventArgs e)
        { //Sil fonksiyonu hatasız çalıştı.
            DialogResult Soru;
            try
            {
                Soru = MessageBox.Show("Personel bilgisini silmek istediğinize emin misiniz?", "Uyarı", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

                if (Soru == DialogResult.Yes)
                {

                    string sorgu = "DELETE FROM Personel WHERE Personel_id=@Personel_id";
                    komut = new SQLiteCommand(sorgu, baglanti);
                    komut.Parameters.AddWithValue("@Personel_id", Convert.ToInt32(textid.Text));
                    baglanti.Open();
                    komut.ExecuteNonQueryAsync();
                    MessageBox.Show("Başarılı bir biçimde kayıt silindi.", "BAŞARILI", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    baglanti.Close();
                    PersonelGetir();
                    ClearTextBoxes();

                }
                else
                {

                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }



        public void button4_Guncelle_Click(object sender, EventArgs e)
        {  //hatalı çalışıyor nedeni buldum  ExecuteNonQueryAsync(); fonk kullanarak senkronizasyon yapılmalı
            // ExecuteNonQuery kullanılırsa bir süre sonra null exception nesne bulunamadı hatası veriyor.
            try { 

            string sorgu = "UPDATE Personel Set Ad=@Ad,Soyad=@Soyad,Katı=@Katı,TelefonNumarası=@TelefonNumarası Where Personel_id=@Personel_id";
            komut = new SQLiteCommand(sorgu, baglanti);
            komut.Parameters.AddWithValue("@Personel_id", Convert.ToInt32(textid.Text));
            komut.Parameters.AddWithValue("@Ad", textAd.Text);
            komut.Parameters.AddWithValue("@Soyad", textSoyad.Text);
            komut.Parameters.AddWithValue("@Katı", combobox_1.Text);
            komut.Parameters.AddWithValue("@TelefonNumarası", textTelefon.Text);
            baglanti.Open();
            komut.ExecuteNonQueryAsync();
            MessageBox.Show("Başarılı bir biçimde kayıt güncellendi.", "BAŞARILI", MessageBoxButtons.OK, MessageBoxIcon.Information);
            baglanti.Close();
            PersonelGetir();
            ClearTextBoxes();
        }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }




        public void button_Listele_Click(object sender, EventArgs e)
        {


           
            baglanti.Open();
            da = new SQLiteDataAdapter("SELECT *FROM Personel ORDER BY Ad COLLATE NOCASE ASC", baglanti);
            DataTable tablo = new DataTable();
            da.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
            ClearTextBoxes();
            




        }

        public void personelGetir2()
        {
           
            baglanti.Open();
            da = new SQLiteDataAdapter("SELECT Ad,Soyad,Katı,TelefonNumarası From Personel WHERE Katı= '0-Zemin kat' ORDER BY Katı,Ad COLLATE NOCASE", baglanti);
            DataTable tablo2 = new DataTable();
            da.Fill(tablo2);
            dataGridView2.DataSource = tablo2;
            baglanti.Close();
        }
        public void personelGetir3()
        {
            
            baglanti.Open();
            da = new SQLiteDataAdapter("SELECT Ad,Soyad,Katı,TelefonNumarası From Personel WHERE Katı= '1.kat' ORDER BY Katı,Ad COLLATE NOCASE", baglanti);
            DataTable tablo3 = new DataTable();
            da.Fill(tablo3);
            dataGridView3.DataSource = tablo3;
            baglanti.Close();
        }

        public void personelGetir4()
        {
           
            baglanti.Open();
            da = new SQLiteDataAdapter("SELECT Ad,Soyad,Katı,TelefonNumarası From Personel WHERE Katı= '2.kat' ORDER BY Katı,Ad COLLATE NOCASE", baglanti);
            DataTable tablo4 = new DataTable();
            da.Fill(tablo4);
            dataGridView4.DataSource = tablo4;
            baglanti.Close();
        }


        public void personelGetir5()
        {
            
            baglanti.Open();
            da = new SQLiteDataAdapter("SELECT Ad,Soyad,Katı,TelefonNumarası From Personel WHERE Katı= '3.kat' ORDER BY Katı,Ad COLLATE NOCASE", baglanti);
            DataTable tablo5 = new DataTable();
            da.Fill(tablo5);
            dataGridView5.DataSource = tablo5;
            baglanti.Close();
        }

        public void personelGetir6()
        {
            
            baglanti.Open();
            da = new SQLiteDataAdapter("SELECT Ad,Soyad,Katı,TelefonNumarası From Personel WHERE Katı= '4.kat' ORDER BY Katı,Ad COLLATE NOCASE", baglanti);
            DataTable tablo6 = new DataTable();
            da.Fill(tablo6);
            dataGridView6.DataSource = tablo6;
            baglanti.Close();
        }

       

        public void button_Cikti_Click(object sender, EventArgs e)
        {
           
            personelGetir2();
            personelGetir3();
            personelGetir4();
            personelGetir5();
            personelGetir6();
               if (dataGridView2.Rows.Count > 0 && dataGridView3.Rows.Count > 0 && dataGridView4.Rows.Count > 0 && dataGridView5.Rows.Count > 0 && dataGridView6.Rows.Count > 0)
            {
                iTextSharp.text.pdf.BaseFont STF_Helvetica_Turkish = iTextSharp.text.pdf.BaseFont.CreateFont("Helvetica", "CP1254", iTextSharp.text.pdf.BaseFont.NOT_EMBEDDED);

                iTextSharp.text.Font fontNormal = new iTextSharp.text.Font(STF_Helvetica_Turkish, 6, iTextSharp.text.Font.NORMAL);
              

                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "PDF (*.pdf)|*.pdf";
                sfd.FileName = "Output.pdf";
                bool fileError = false;
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    if (File.Exists(sfd.FileName))
                    {
                        try
                        {
                            File.Delete(sfd.FileName);
                        }
                        catch (IOException ex)
                        {
                            fileError = true;
                            MessageBox.Show("bu diske yazmak imkansız." + ex.Message);
                        }
                    }
                    if (!fileError)
                    {
                        try
                        {
                            // Veri tabanlarında çoklu komutlar çalıştırmanın yolları nelerdir? nesnelere bölmek 

                            PdfPTable pdfTable = new PdfPTable(dataGridView2.Columns.Count);
                            
                            pdfTable.DefaultCell.Padding = 3;
                            pdfTable.WidthPercentage = 100;
                            pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;
                          
                            PdfPTable pdfTable2 = new PdfPTable(dataGridView3.Columns.Count);
                            
                            pdfTable2.DefaultCell.Padding = 3;
                            pdfTable2.WidthPercentage = 100;
                            pdfTable2.HorizontalAlignment = Element.ALIGN_LEFT;


                            PdfPTable pdfTable3 = new PdfPTable(dataGridView4.Columns.Count);
                            
                            pdfTable3.DefaultCell.Padding = 3;
                            pdfTable3.WidthPercentage = 100;
                            pdfTable3.HorizontalAlignment = Element.ALIGN_LEFT;

                            PdfPTable pdfTable4 = new PdfPTable(dataGridView5.Columns.Count);
                            
                            pdfTable4.DefaultCell.Padding = 3;
                            pdfTable4.WidthPercentage = 100;
                            pdfTable4.HorizontalAlignment = Element.ALIGN_LEFT;

                            PdfPTable pdfTable5 = new PdfPTable(dataGridView6.Columns.Count);
                           
                            pdfTable5.DefaultCell.Padding = 3;
                            pdfTable5.WidthPercentage = 100;
                            pdfTable5.HorizontalAlignment = Element.ALIGN_LEFT;


                            foreach (DataGridViewColumn column in dataGridView2.Columns)
                            {
                                PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText,new Font(fontNormal)));
                                cell.BackgroundColor = new iTextSharp.text.BaseColor(192, 192, 192);
                                pdfTable.AddCell(cell);
                                
                            }
                            pdfTable.SpacingAfter = 20;

                            foreach (DataGridViewColumn column in dataGridView3.Columns)
                            {
                                PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText,new Font(fontNormal)));
                                cell.BackgroundColor = new iTextSharp.text.BaseColor(192, 192, 192);
                                pdfTable2.AddCell(cell);
                            }
                            pdfTable2.SpacingAfter = 20;

                            foreach (DataGridViewColumn column in dataGridView4.Columns)
                            {
                                PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText, new Font(fontNormal)));
                                cell.BackgroundColor = new iTextSharp.text.BaseColor(192, 192, 192);
                                pdfTable3.AddCell(cell);
                            }
                            pdfTable3.SpacingAfter = 20;

                            foreach (DataGridViewColumn column in dataGridView5.Columns)
                            {
                                PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText, new Font(fontNormal)));
                                cell.BackgroundColor = new iTextSharp.text.BaseColor(192, 192, 192);
                                pdfTable4.AddCell(cell);
                            }
                            pdfTable4.SpacingAfter = 20;
                            foreach (DataGridViewColumn column in dataGridView6.Columns)
                            {
                                PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText, new Font(fontNormal)));
                                cell.BackgroundColor = new iTextSharp.text.BaseColor(192, 192, 192);
                                pdfTable5.AddCell(cell);
                            }
                            //pdfTable5.SpacingAfter = 20;




                            foreach (DataGridViewRow row in dataGridView2.Rows)
                            {
                                foreach (DataGridViewCell cell in row.Cells)
                                {
                                    if (cell.Value == null)
                                    {
                                        // your cell value is null, do something in null value case
                                    }
                                    else
                                    {
                                        pdfTable.AddCell(new Phrase(cell.Value.ToString(), new Font(fontNormal)));
                                    }

                                        
                                      //pdfTable.AddCell(new Phrase(cell.Value.ToString(), new Font(fontNormal)));





                                }
                            }

                          
                            foreach (DataGridViewRow row1 in dataGridView3.Rows)
                            {
                                foreach (DataGridViewCell cell1 in row1.Cells)
                                {
                                    if (cell1.Value == null)
                                    {
                                        // your cell value is null, do something in null value case
                                    }
                                    else
                                    {
                                        pdfTable2.AddCell(new Phrase(cell1.Value.ToString(), new Font(fontNormal)));
                                    }

                                    //pdfTable2.AddCell(cell1.Value == null ? "" : cell1.Value.ToString());




                                }
                            }

                            foreach (DataGridViewRow row2 in dataGridView4.Rows)
                            {
                                foreach (DataGridViewCell cell2 in row2.Cells)
                                {

                                    if (cell2.Value == null)
                                    {
                                        // your cell value is null, do something in null value case
                                    }
                                    else
                                    {
                                        pdfTable3.AddCell(new Phrase(cell2.Value.ToString(), new Font(fontNormal)));
                                    }

                                    //pdfTable3.AddCell(cell2.Value == null ? "" : cell2.Value.ToString());




                                }
                            }

                            foreach (DataGridViewRow row3 in dataGridView5.Rows)
                            {
                                foreach (DataGridViewCell cell3 in row3.Cells)
                                {

                                    if (cell3.Value == null)
                                    {
                                        // your cell value is null, do something in null value case
                                    }
                                    else
                                    {
                                        pdfTable4.AddCell(new Phrase(cell3.Value.ToString(), new Font(fontNormal)));
                                    }

                                    //pdfTable4.AddCell(cell3.Value == null ? "" : cell3.Value.ToString());




                                }
                            }

                            foreach (DataGridViewRow row4 in dataGridView6.Rows)
                            {
                                foreach (DataGridViewCell cell4 in row4.Cells)
                                {   
                                    if (cell4.Value == null)
                                    {
                                        // your cell value is null, do something in null value case
                                    }
                                    else
                                    {
                                        pdfTable5.AddCell(new Phrase(cell4.Value.ToString(), new Font(fontNormal)));
                                    }
                                    //pdfTable5.AddCell(cell4.Value == null ? "" : cell4.Value.ToString());
                                    }
                            }


                              using (FileStream stream = new FileStream(sfd.FileName, FileMode.Create))
                            {
                                Document pdfDoc = new Document(PageSize.A4, 10f, 20f, 20f, 10f);
                                PdfWriter.GetInstance(pdfDoc, stream);
                                pdfDoc.Open();
                                pdfDoc.Add(pdfTable);
                                pdfDoc.Add(pdfTable2);
                                pdfDoc.Add(pdfTable3);
                                pdfDoc.Add(pdfTable4);
                                pdfDoc.Add(pdfTable5);
                                pdfDoc.Close();
                                stream.Close();
                            }

                            MessageBox.Show("Başarılı sekilde çıktı alındı", "Başarılı");



                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Hata :" + ex.Message);
                        }
                    }

                }
            }
        } 

        private void button_Temiz_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
        }


    }








}
     
